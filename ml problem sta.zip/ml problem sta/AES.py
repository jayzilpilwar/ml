from collections import deque

p10 = [3, 5, 2, 7, 4, 10, 1, 9, 8, 6]
p8 = [6, 3, 7, 4, 8, 5, 10, 9]
IP = [2,6,3,1,4,8,5,7]
IPinv = [4,1,3,5,7,2,8,6]
EP = [4,1,2,3,2,3,4,1]
S0 = [[1,0,3,2],[3,2,1,0],[0,2,1,3],[3,1,3,2]]
S1 = [[0,1,2,3],[2,0,1,3],[3,0,1,0],[2,1,0,3]]
p4 = [2,4,3,1]


# performs juggelery
def initial_permutation10(word):
    global p10
    ans = []
    for each in p10:
        ans.append(word[each - 1])
    return ans

def left_shift_key1(word):
     lhs=[]
     rhs=[]
     w=[]
     for i in range(5,10):
         w.append(word[i])
     print(w)
     for i in range(5):

         lhs.append(word[(i+1)%5])
         rhs.append(w[(i+1)%5])
     # print(lhs+rhs)
     return lhs+rhs

def left_shift_key2(word):
    key2 = left_shift_key1(word)
    key2 = left_shift_key1(key2)

    return key2
    
def IP_func(word):
    ans=[]
    global IP
    for each in IP:
        ans.append(word[each-1])
    return ans

def inv_IP(word):
    ans=[]
    global IPinv
    for each in IPinv:
        ans.append(word[each-1])
    return ans

def ExP(word):
    ans=[]
    global EP
    for each in EP:
        ans.append(word[each-1])
    return ans

get_bin = lambda x: format(x, 'b')

def functionK(word,key):


    lhs=[word[i] for i in range(4)]
    rhs=[word[i] for i in range(4,8)]

    #dealing with rhs

    rhs_ep = ExP(rhs)
    # print("exp L: ",rhs_ep)
    # print("key xor L ",key)
    rhs_key_xor=[]
    # for i in range(8):
    #     print(rhs_ep[i] , "  ",key[i],"  ",int((int(rhs_ep[i])!=int(key[i])))," ",(rhs_ep[i]!=key[i]))
    #     rhs_key_xor.append(int(rhs_ep[i]!=key[i]))

    rhs_key_xor = [int(int(rhs_ep[i])!=int(key[i])) for i in range(8)]
    # print("xor : ",rhs_key_xor)

    #SBOX

    s0r=int(str(rhs_key_xor[0])+str(rhs_key_xor[3]),2)
    s0c=int(str(rhs_key_xor[1])+str(rhs_key_xor[2]),2)

    first_elem = S0[s0r][s0c]

    s1r=int(str(rhs_key_xor[4])+str(rhs_key_xor[7]),2)
    s1c=int(str(rhs_key_xor[5])+str(rhs_key_xor[6]),2)

    second_elem = S1[s1r][s1c]
    # print("first ",first_elem,"sec ",second_elem)
    f = "{0:b}".format(first_elem)
    if(len(f)==1):
        f = "0"+f
    s = "{0:b}".format(second_elem)
    if(len(s)==1):
        s = "0"+s
    sbox_4bit_op =list(f)+list(s)

    # print("sbox : ",sbox_4bit_op)

    # print("sboxop ",sbox_4bit_op)
    global p4
    ans = []
    for each in p4:
            ans.append(sbox_4bit_op[each-1])
    # print("per : ",ans)

    ans = [int(int(lhs[i]) != int(ans[i])) for i in range(4)]
    # print("after xor ,",ans)
    return ans+rhs

def switch(word):
    ans = []
    for i in range(4,8):
        ans.append(word[i])
    for i in range(4):
        ans.append(word[i])

    return ans
            
# takes 4 bits and converts to 8
def permutation_8bit(word):
    global p8
    ans = []
    for each in p8:
        ans.append(word[each-1])
    return ans

def main():
    key = list(input())
    key = initial_permutation10(key)
    # print(key)
    key1_LS = left_shift_key1(key)
    # print(key1_LS)
    key1 = permutation_8bit(key1_LS)
    print(key1)

    key2_LS = left_shift_key2(key1_LS)
    # print(key2_LS)
    key2 = permutation_8bit(key2_LS)
    print(key2)

    word = list(input())
    word_IP = IP_func(word)
    print("IP : ",word_IP)
    word_f = functionK(word_IP,key1)
    print("fk1 ",word_f)
    word_switched = switch(word_f)
    print("switchef  ",word_switched)
    word_k2 = functionK(word_switched,key2)
    print("fk2 ",word_k2)
    word_inv = inv_IP(word_k2)

    print(word_inv,"here")


    word_IP = IP_func(word_inv)
    print("IP : ",word_IP)
    word_k2 = functionK(word_IP,key2)
    print("fk1 ",word_k2)
    word_switched = switch(word_k2)
    print("switchef  ",word_switched)

    word_k1 = functionK(word_switched,key1)
    print("fk2 ",word_k1)
    word_inv = inv_IP(word_k1)


    print(word_inv,"dec")

main()