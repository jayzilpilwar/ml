<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="qrichtext" content="1" /><style type="text/css">
p, li { white-space: pre-wrap; }
</style></head><body style=" font-family:'Consolas'; font-size:13pt; font-weight:400; font-style:normal;">
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">Type &quot;copyright&quot;, &quot;credits&quot; or &quot;license&quot; for more information.</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><br /></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">IPython 7.2.0 -- An enhanced Interactive Python.</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><br /></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">In [</span><span style=" font-weight:600; color:#000080;">1</span><span style=" color:#000080;">]:</span> from sklearn.linear_model import LinearRegression</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> import numpy as np</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> import matplotlib.pyplot as plt</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> </p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> x=np.array([10,9,2,15,10,16,11,16]).reshape(-1,1)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> y=np.array([95,80,10,50,45,98,38,93]).reshape(-1,1)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> </p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> model=LinearRegression()</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> model.fit(x,y)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> print(model.score(x,y))</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> ypred=model.predict(x)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> </p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> plt.xlabel('Number of hours spent driving')</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> plt.ylabel('Risk score')</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> plt.scatter(x,y)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> plt.plot(x,ypred)</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">   ...:</span> plt.show()</p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">0.43709481451010035</p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><br /></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><img src="data:image/png;base64,
iVBORw0KGgoAAAANSUhEUgAAAYgAAAEKCAYAAAAIO8L1AAAACXBIWXMAAAsS
AAALEgHS3X78AAAAO3pUWHRTb2Z0d2FyZQAACJnLTSwpyMkvyclMUihLLSrO
zM9TMNYz0DPSUcgoKSmw0tfPhSvQyy9K1wcApwUQ8aaEwSQAACAASURBVHic
7d17QM33/wfwZ1dCKlN0kWpIiG7KbSotGVabuxmZaHy3YTZf+W7Dd76SsbnN
Nn01y2Uy5lvGXHNnjUiYSZNQGlHJpdQ5vX9/9HO2o5MTOudzTj0f//XqnM6z
ouc55/N5f94GQggBIiKixxhKHYCIiHQTC4KIiFRiQRARkUosCCIiUokFQURE
KrEgiIhIJRYEERGpxIIgIiKVWBBERKSSsdQBnkfz5s3h5OQkdQwiIr2SnZ2N
W7duqb2dXheEk5MTUlNTpY5BRKRXfHx8anQ7jb3FNG7cONjY2KBTp06KWUFB
AYKDg9G2bVsEBwejsLAQACCEwOTJk9GmTRt07twZp06d0lQsIiKqIY0VxNix
Y7Fz506lWUxMDIKCgpCZmYmgoCDExMQAAHbs2IHMzExkZmYiNjYWkyZN0lQs
IiKqIY0VRO/evdGsWTOlWVJSEsLDwwEA4eHhSExMVMzHjBkDAwMDdOvWDUVF
RcjLy9NUNCIiqgGtnsV048YN2NraAgBsbW1x8+ZNAEBubi5atWqluJ2DgwNy
c3O1GY2IiB6jEwepVW1JYWBgoPK2sbGxiI2NBQDk5+drNBcRUX2m1VcQLVq0
ULx1lJeXBxsbGwCVrxiuXbumuF1OTg7s7OxUfo3IyEikpqYiNTUV1tbWmg9N
RKQjEtNy0TNmH5yjtqNnzD4kpmn2nRatFkRoaCji4+MBAPHx8QgLC1PM16xZ
AyEEUlJSYGFhoXgrioiIKsth5pazyC0qgQCQW1SCmVvOarQkNFYQI0eORPfu
3ZGRkQEHBwfExcUhKioKe/bsQdu2bbFnzx5ERUUBAPr37w8XFxe0adMGEyZM
wFdffaWpWEREemnhrgyUlMuVZiXlcizclaGxx9TYMYgNGzaonCcnJ1eZGRgY
YMWKFZqKQkSk964XlTzVvDbwWkxERHrAztLsqea1gQVBRKQHpoe4wszESGlm
ZmKE6SGuGntMnTjNlYiInuw1T3sAlccirheVwM7SDNNDXBVzTWBBEOmBxLRc
rf5hIN30mqe9Vn/vLAgiHffo9MZHZ7A8Or0RAEuCNIrHIIh0nBSnNxIBLAgi
nSfF6Y1EAAuCSOdJcXojEcCCINJ5UpzeSLpJ29di4kFqIh0nxemNpHukOFmB
BUGkB7R9eiPpniedrKCpfxt8i4mISA/wWkxERKQSr8VEREQq8VpMRESkEq/F
RERE1dL2yQp8i4mIiFRiQRARkUosCCIiUokFQUREKrEgiIhIJRYEERGpxIIg
IiKVWBBERKQSC4KIiFRiQRAR6ZG4I5fhFLUdJWVy9Td+TrzUBhGRHpiz9Td8
dyxb8fHBi/no16mlRh+TBUFEpMPCvz2OgxfzlWbrIvzQq21zjT82C4KISMfI
KwQCFu3HtQLlzYB+nvwSOtg11VoOFgQRkY4oLZej/Sc7q8x/mdkHthaa2xio
OiwIIiKJFd4vg+fcPVXm6bP7wsLMRIJElVgQREQSuXr7AXov3K80a2hiiDOz
Q2BqLP1JpiwIIiItS79WhLAVR5Vm7Vua4+fJL8HQ0ECiVFWxIIiItCT59xuI
iE9Vmg1wt8WKUV4SJXoyFgQRkYatS7mCjxPPKc0mBbyIGf3aS5SoZlgQREQa
Mm3jaWxJy1WazXu9E0b5tZYo0dORpCAWL16MVatWwcDAAO7u7li9ejXy8vIw
YsQIFBQUwMvLC2vXroWpqakU8YiInotT1PYqs7hwHwS5tZAgzbPT+mHy3Nxc
LFu2DKmpqTh37hzkcjkSEhIwY8YMvP/++8jMzISVlRXi4uK0HY3ouSWm5aJn
zD44R21Hz5h9SHzs2SPVXRUVAk5R26uUQ0JkN2THDNC7cgAkegUhk8lQUlIC
ExMTPHjwALa2tti3bx++//57AEB4eDjmzJmDSZMmSRGP6JkkpuVi5pazKCmv
vIhablEJZm45CwB4zdNeymikQSVlcrjNqrq4bcs/esDL0UqCRLVH6wVhb2+P
Dz/8EI6OjjAzM0Pfvn3h7e0NS0tLGBtXxnFwcEBuLp95kX5ZuCtDUQ6PlJTL
sXBXBguiDrpRXAq/6OQq88P/DESrZo0kSFT7tF4QhYWFSEpKwuXLl2FpaYmh
Q4dix44dVW5nYKD6XODY2FjExsYCAPLz81XehkgK14tKnmpO+um363cwYNmR
KvOzc/rCvKF0q541QesFsXfvXjg7O8Pa2hoAMGjQIBw7dgxFRUWQyWQwNjZG
Tk4O7OzsVN4/MjISkZGRAAAfHx+t5SZSx87SDLkqysDOUvvX0KHat/f8DYxf
k1pl/se8V2BsJP2qZ03Q+nfl6OiIlJQUPHjwAEIIJCcno0OHDggMDMTmzZsB
APHx8QgLC9N2NKLnMj3EFWYmRkozMxMjTA9xlSgR1YZVh7PgFLW9SjlkxwxA
dsyAOlsOgASvIPz8/DBkyBB4eXnB2NgYnp6eiIyMxIABAzBixAh8/PHH8PT0
REREhLajET2XR8cZFu7KwPWiEthZmmF6iCuPP+ipGZvPYGPqNaWZeQNjnP13
iESJtM9ACCGkDvGsfHx8kJpa9SUfEdGz6r/0MM7nFSvNXmrbHGsj/CRKVPtq
+reTK6mJiKB6cVtkbxf8q7+bBGl0AwuCiOotIQScZ/5cZf7Z4M4Y1rWVBIl0
CwuCiOqdhzI5XD+uurjt+wl+6PGi5vd61hcsCCKqNwrul8FLxc5t+z7wh4t1
EwkS6TYWBBHVeX/cvIeXvzhYZZ72STCsGvOioNVhQRBRnXX0j1sYterXKvOL
/3lFJ7b01HUsCCKqczYcv6q4UOLfXZ7fv9rL+FBVLAgiqjPmbjuPuCOXq8yz
YwZIkEb/sSCISO+NjE3BL1m3lWadHSyw9d1eEiWqG1gQRKS32n+yA6XlFUqz
kb6OmD/IXaJEdQsLgoj0SnWL22YN7IBxvZwlSFR3sSCISC/I5BVo81HVvWO+
HeuDPu31bztPfcCCICKdVlxajs5zdleZ75jyEtxsm0qQqP5gQRCRTrpW8AAv
fba/yvz4R0GwMW8oQaL6hwVBRDrl5JUCDP76lyrzC3P7oeFjGzKRZrEgiEgn
JJ3OxZSE01XmWdH9YWjIxW1SYEEQkaS+2HMRy5Izq8y5uE16LAgikkTkmlTs
Pn9Daeb0QiMcmB4oUSJ6HAuCiLSqW3Qy/iwuVZoN7GyLL9/wkigRVYcFQURa
oWpLz+khrngnsI0EaagmWBBEpDEVFQIu/6q66nnFG14Y0NlWgkT0NFgQRFTr
HpTJ0GHWrirzpHd6oksrSwkS0bNgQRBRrfnzTim6zU+uMj8a1Qf2lmYSJKLn
wYIgoud2LvcOBi4/UnX+7xA0acA/M/qKvzkiema7fvsTb689WWV+Kbo/jLi4
Te+xIIjoqcUeuoTony9UmXNxW93CgiCiGvvgh3T8eCpHaWbVyARps/pKlIg0
iQVBRGr1W3IIF/68qzQLcLXGd2/5SpSItIEFQUTVUrW4baL/i4h6pb0EaUjb
alQQV65cQWZmJl5++WWUlJRAJpPB3Nxc09mISALVbem5aGgXDPF2kCARSUVt
Qfz3v/9FbGwsCgoKcOnSJeTk5GDixIlITq56rjMR6a/Scjnaf7KzynxjZDf4
ubwgQSKSmtqCWLFiBY4fPw4/Pz8AQNu2bXHz5k2NByMi7bh97yG8/7O3yvzA
hwFwat5YgkSkK9QWRIMGDWBqaqr4WCaTwcCA5zcT6bsbxaXwi676TkD6rL6w
aGQiQSLSNWoLwt/fH9HR0SgpKcGePXvw1Vdf4dVXX9VGNiLSgMwbdxG8+FCV
+cX/vAJTY0MJEpGuUlsQMTExiIuLg7u7O1auXIn+/ftj/Pjx2shGRLUoJes2
RsSmKM16tnkB6yL8+K4AqfTEgpDL5QgPD8e6deswYcIEbWUiolq0Nf06Jm9I
U5qN8nPEvNfdJUpE+uKJBWFkZIT8/HyUlZUpHYd4XkVFRRg/fjzOnTsHAwMD
fPvtt3B1dcXw4cORnZ0NJycn/PDDD7Cysqq1xySqb1YevIT5O5QvhxH1SntM
9H9RokSkb9S+xeTk5ISePXsiNDQUjRv/dUbDtGnTnvlBp0yZgn79+mHz5s0o
KyvDgwcPEB0djaCgIERFRSEmJgYxMTFYsGDBMz8GUX31ceJZrEu5qjRbOsID
YR72EiUifaW2IOzs7GBnZ4eKigrcvXtX3c3VKi4uxqFDh/Ddd98BAExNTWFq
aoqkpCQcOHAAABAeHo6AgAAWBFENCSEwatWvOHbpttI8IbIbunENAz0jtQUx
e/ZsAMDdu3dhYGCAJk2aPNcDZmVlwdraGm+99RbS09Ph7e2NpUuX4saNG7C1
rdyC0NbWlmstiGpAXiHQM2Yf/iwuVZrvfr832rXg1Q7o+agtiHPnzmH06NEo
KCgAADRv3hxr1qxBx44dn+kBZTIZTp06heXLl8PPzw9TpkxBTExMje8fGxuL
2NhYAEB+fv4zZSDSdyVlcrjNqrrq+dd/BaFF04YSJKK6SG1BREZG4osvvkBg
YCAA4MCBA5gwYQKOHTv2TA/o4OAABwcHxcrsIUOGICYmBi1atEBeXh5sbW2R
l5cHGxubavNERkYCAHx8fJ4pA5G+qm7VM3duI01Q+y/q/v37inIAgICAANy/
f/+ZH7Bly5Zo1aoVMjIy4OrqiuTkZHTo0AEdOnRAfHw8oqKiEB8fj7CwsGd+
DKK65ubdUvjOU171bN7QGKc+CYaJERe3kWaoLQgXFxfMnTsXo0ePBgCsW7cO
zs7Oz/Wgy5cvx6hRo1BWVgYXFxesXr0aFRUVGDZsGOLi4uDo6IhNmzY912MQ
1QWXb91H4KIDSrO2Nk2w+/3eXNxGGmcghBBPukFhYSFmz56NI0cqNyTv3bs3
Zs+erRNrFHx8fJCamip1DKJal36tCGErjirN5rzaAWN7Pt+TMyKg5n871b6C
sLKywrJly2olFBE92YGMmxi7+oTS7Ms3PDGws51Eiag+U/vmZXBwMIqKihQf
FxYWIiQkRKOhiOqbLady4BS1Xakcvp/gh+yYASwHkozaVxC3bt2CpaWl4mMr
KyuuUSCqJd8cvISYxy6H8fPkl9DBrqlEiYj+orYgDA0NcfXqVTg6OgKo3H6U
B8eInl1FhcDc7eex+mi2YtbQxBB73vdHq2aNpAtG9Bi1BTFv3jz06tUL/v7+
AIBDhw4pFqoRUc2VyyswNeE0tp/NU8xav9AIWyb1wAtNGkiYjEg1tQXRr18/
nDp1CikpKRBCYPHixWjevLk2shHVCfcfyhD+7XGkXilUzHydmuG7cV3RyJSL
20h3qT1IffToUZiZmWHgwIG4c+cOoqOjceXKFW1kI9Jrt+89RK8F+9Bx9i5F
OQzsbIvMea/gh4ndWQ6k89T+C500aRLS09ORnp6OhQsXYty4cRgzZgwOHjyo
jXxEeudawQMEfX4QZfIKxWx8L2d8NMCNx+9Ir6gtCGNjYxgYGCApKQmTJ09G
REQE4uPjtZGNSK+cy72DgcuPKM3+1b89Intzgx7ST2oLwtzcHPPnz8e6detw
6NAhyOVylJeXayMbkV449sctvLHqV6XZ4uFd8Lqng0SJiGqH2oLYuHEjvv/+
e8TFxaFly5a4evUqpk+fro1sRDrtp/TreO+xvZ7jx/nCv521RImIapfaazHp
Ml6LiaSw+uhl/Pun80qzre/2RGcHy2ruQaRbau1aTERUuaXngp0Z+ObgJcXM
wADY90EAnJs3fsI9ifQXC4LoCWTyCkzffAb/S8tVzGwtGiLp3Z6wMefObVS3
qS2IkydPwtvbW2n2008/4dVXX9VYKCKplZTJERF/Ascu3VbMurSyxLoIX5g3
NJEwGemLxLRcLNyVgetFJbCzNMP0EFe85mkvdaynorYgJkyYgPj4eLi7uwMA
NmzYgCVLlrAgqE4qelCGwV8fw6X8v3ZN7NuhBZa/4YkGxkYSJiN9kpiWi5lb
zqKkXA4AyC0qwcwtZwFAr0pCbUFs3rwZQ4YMwfr163HkyBGsWbMGu3fv1kY2
Iq3JLSpBv8WHcPehTDEb3a01/h3aEYaGXNxGT2fhrgxFOTxSUi7Hwl0Zdasg
XFxckJCQgNdeew2tWrXC7t27YWZmpo1sRBqX8eddhCw5pDT7sG87vBPYhque
6ZldLyp5qrmuqrYg3N3dlf6DFBQUQC6Xw8/PDwBw5swZzacj0pDjlwswbOUv
SrMFg90xvKujRImoLrGzNEOuijKws9SvJ9fVFsS2bdu0mYNIK3b99ifeXntS
abZqjA9e7tBCokRUF00PcVU6BgEAZiZGmB7iKmGqp1dtQbRu3RoAcOnSJTg4
OKBBgwY4cOAAzpw5gzFjxmgtIFFtWP/rFXz0v3NKsx8ndYd362YSJaK67NFx
Bn0/i0ntSmoPDw+kpqYiOzsbISEhCA0NRUZGBn7++WdtZawWV1LTkwghsGRv
JpYmZyrN907rjTY25hKlIpJera2kNjQ0hLGxMbZs2YKpU6fivffeg6enZ62E
JNIEeYXAR/87i4QT1xSzZo1N8fPkl9DSgovbiGpKbUGYmJhgw4YNWLNmDX76
6ScA4NVcSSeVlssxad1J7M/IV8zatzTHxre7w8KMi9uInpbagli9ejW++eYb
fPTRR3B2dsbly5fx5ptvaiMbUY0Ul5ZjxMoUnM8rVsz821lj5WhvNDTh4jai
Z8WruZLeulFcigHLDuPWvTLFbJiPA+YP6gyjOra4rS5ctoF0x3Mfgxg2bBh+
+OGHKushhBAwMDDgOgiSzKX8ewj6XHnL2/f6tMG04HZ1cnFbXblsA+mfagti
6dKlALgegnRH2tVCvP7VMaXZ3LCOGN3dSZpAWlJXLttA+qfagrC1tQXw13qI
R+RyORISEqrMiTRl/4WbeOu7E0qzr0d54RV3W4kSaVdduWwD6Z9qC6K4uBgr
VqxAbm4uQkNDERwcjC+//BKLFi2Ch4cHRo0apc2cVA9tPpmDDzelK80SIruh
m8sLEiWSRl25bAPpn2oLYvTo0bCyskL37t2xatUqLFy4EGVlZUhKSoKHh4c2
M1I989WBP/DZzgyl2Y4pL8HNtqlEiaRVVy7bQPqn2oLIysrC2bOVB8LGjx+P
5s2b4+rVqzA35wpUqn0VFQKfbjuP745lK2aNTY2w6/3ecLBqJF0wHVBXLttA
+qfagjAx+WthkZGREZydnVkOVOvKZBWYvCENO3/7UzFzad4YP07qAavGphIm
0y2vedqzEEjrqi2I9PR0NG1a+ZJeCIGSkhI0bdpUcZprcXFxdXclUuveQxlG
x/2KtKtFilk3l2b4dmxXNDLlVulEuqDa/4lyuby6TxE9s1v3HiLsy6NKB13D
POzw+dAuMDYylDAZET2OT9VIK67cvo+gzw9CVvHXwv3I3i6Y+Ur7Orm4jagu
kKwg5HI5fHx8YG9vj23btuHy5csYMWIECgoK4OXlhbVr18LUlO9B67tzuXcw
cPkRpdnHA9ww/iUXiRIRUU1J9pp+6dKlcHNzU3w8Y8YMvP/++8jMzISVlRXi
4uKkika14EjmLThFbVcqh6UjPJAdM4DlQKQnJCmInJwcbN++HePHjwdQeRB8
3759GDJkCAAgPDwciYmJUkSj57Q1/TqcorbjzbhfFbO1Eb7IjhmAMA+ehUOk
TyR5i2nq1Kn47LPPcPfuXQDA7du3YWlpCWPjyjgODg7Izc2VIho9o7gjlzF3
23ml2U/v9oK7g4VEiYjoeWm9ILZt2wYbGxt4e3vjwIEDACpfQTyuugOXsbGx
iI2NBQDk5+ervA1phxACMTsuYOWhLMXM2NAAyR/4o/ULjSVMRkS1QesFcfTo
UWzduhU///wzSktLUVxcjKlTp6KoqAgymQzGxsbIycmBnZ2dyvtHRkYiMjIS
QOU1zUn7ZPIKfLApHUmnrytm9pZmSHynJ6zNG0iYjJ4W95mgJ9H6MYj58+cj
JycH2dnZSEhIQJ8+fbB+/XoEBgZi8+bNAID4+HiEhYVpOxqpUVImx4jYX9Dm
ox2KcvBytMS5f4fgaFQfloOeebTPRG5RCQT+2mciMY1v71IlnVkHsWDBAowY
MQIff/wxPD09ERERIXUk+n+F98sw+OtjyLp1XzHr17Ello30hKkxF7fpK+4z
QepIWhABAQEICAgAALi4uOD48eNSxqHH5BaVoO8XB3G/7K8/ImN7OGHWwA4w
rGNbetZH3GeC1NGZVxCkOy78WYx+Sw4rzaaHuOKdwDYSJSJN4D4TpA4LghR+
zbqN4bEpSrPPhnTGMJ9WEiUiTeI+E6QOC4Kw81weJq47pTT7dqwP+rRvIVEi
0gbuM0HqsCDqsbUpV/BJ4jml2ZZ/9ICXo5VEiUjbuM8EPQkLop4RQuCLPRex
fN8fSvPkD/zxonUTiVIRkS5iQdQT8gqBmVvO4IfUHMWseRNTbJ/8Elo0bShh
MiLSVSyIOq60XI6J607iQMZflyXpYNsUGyK7wcLM5An3JKL6jgVRR90pKcfw
lb/gwp93FbM+7W3w1SgvNDQxkjAZEekLFkQd8+edUvRfdhgF98sUsxFdW2He
6+4w4uI2InoKLIg64o+b9/DyFweVZlOC2mLqy225pScRPRMWhJ47eaUQg78+
pjT7z2ud8Ga31hIlIqK6ggWhp/ZduIFx36Uqzb550xv9OrWUKBER1TUsCD3z
w4lr+OePZ5Rnb3eHr3MziRIRUV3FgtATK/b/gYW7MpRmu6b2hmtLc4kSEVFd
x4LQYRUVAnN++g1rfrmimJk3NMbOqb1hzytuEpGGsSB0UJmsAu9+fwq7z99Q
zNrYNMHmid1h2chUwmREVJ+wIHTIvYcyvLnqV5y+VqSY9WzzAlaN6QozUy5u
IyLtYkHogPy7DxH65RHk3SlVzAZ52uOzIZ1hbMQtPYlIGiwICWXfuo8+nx9A
hfhrNtH/Rczo58rFbUQkORaEBM7m3MGrXx5Rmn0ysAMiejlLlIiIqCoWhBYd
zszH6LjjSrNlIz0R2sVOokRERNVjQWhBYloupm48rTRbP94PPds0lygREZF6
LAgNWnU4C//Z/rvSbNt7vdDJ3kKiRERENceCqGVCCMzb/jtWHbmsmJkaGWLv
NH84vtBIwmRERE+HBVFLZPIKTPshHVvTrytmrZqZIfEfPfFCkwYSJiMiejYs
iOf0oEyGsatP4PjlAsXMp7UV4sf5onED/niJSH/xL9gzKrxfhkFfH8PlW/cV
swHutlgywgMmXNxGRHUAC+Ip5RQ+QPAXh1BSLlfMxvV0xscD3GDILT2JqA5h
QdTQ73nFeGXpYaVZ1CvtMdH/RYkSERFpFgtCjZSs2xgRm6I0+3xoFwz2dpAo
ERGRdrAgqvHz2Tz8Y/0ppdl3b3VFgKuNRImIiLSLBfGYNb9kY1bSb0qzxHd6
wqOVpTSBiIgkwoJA5eK2z3dfxJf7/1Ca7/vAHy7WTSRKRUQkrXpdEPIKgagf
z2DTyRzFzMa8Aba91ws2TRtKmIyISHr1tiDGx6di7+9/benpbm+B9RP80LSh
iYSpiIh0R70siJSs24pyeNnNBitGeaGBMbf0JCL6O60v+b127RoCAwPh5uaG
jh07YunSpQCAgoICBAcHo23btggODkZhYaHGMnRzeQGbJ3ZHVnR/rArvynIg
IlJB6wVhbGyMzz//HL///jtSUlKwYsUKnD9/HjExMQgKCkJmZiaCgoIQExOj
0Rw+Ts248pmI6Am0XhC2trbw8vICAJibm8PNzQ25ublISkpCeHg4ACA8PByJ
iYnajkZERH8j6TGI7OxspKWlwc/PDzdu3ICtrS2AyhK5efOmyvvExsYiNjYW
AJCfn6+1rERE9Y1klx29d+8eBg8ejCVLlqBp06Y1vl9kZCRSU1ORmpoKa2tr
DSYkIqrfJCmI8vJyDB48GKNGjcKgQYMAAC1atEBeXh4AIC8vDzY2vKQFEZGU
tF4QQghERETAzc0N06ZNU8xDQ0MRHx8PAIiPj0dYWJi2oxER0d9o/RjE0aNH
sXbtWri7u8PDwwMAEB0djaioKAwbNgxxcXFwdHTEpk2btB2NiIj+RusF0atX
LwghVH4uOTlZy2mIiKg63BuTiIhUYkEQEZFKLAgiIlKJBUFERCqxIIiISCUW
BBERqcSCICIilVgQRESkEguCiIhUYkEQEZFKLAgiIlKJBUFERCqxIIiISCUW
BBERqSTpntRSSEzLxcJdGbheVAI7SzNMD3HFa572UsciItI59aogEtNyMXPL
WZSUywEAuUUlmLnlLACwJIiIHlOv3mJauCtDUQ6PlJTLsXBXhkSJiIh0V70q
iOtFJU81JyKqz+pVQdhZmj3VnIioPqtXBTE9xBVmJkZKMzMTI0wPcZUoERGR
7qpXB6kfHYjmWUxEROrVq4IAKkuChUBEpF69eouJiIhqjgVBREQqsSCIiEgl
FgQREanEgiAiIpUMhBBC6hDPqnnz5nBycnqm++bn58Pa2rp2A2mQPuXVp6yA
fuXVp6yAfuWtT1mzs7Nx69YttbfT64J4Hj4+PkhNTZU6Ro3pU159ygroV159
ygroV15mrYpvMRERkUosCCIiUslozpw5c6QOIRVvb2+pIzwVfcqrT1kB/cqr
T1kB/crLrMrq7TEIIiJ6Mr7FREREKtW7grh27RoCAwPh5uaGjh07YunSpVJH
Uksul8PT0xMDBw6UOopaRUVFGDJkCNq3bw83Nzf88ssvUkeq1uLFi9GxY0d0
6tQJI0eORGlpqdSRlIwbNw42Njbo1KmTYlZQUIDg4GC0bdsWwcHBKCwslDDh
X1RlnT59Otq3b4/OnTvj9ddfR1FRkYQJlanK+8iiRYtgYGBQo9NAtaG6rMuX
L4erqys6duyIf/7znxp57HpXEMbGxvj888/x+++/IyUlBStWrMD58+eljvVE
S5cuhZubm9QxamTKlCno168fLly4gPT0dJ3NnZubi2XLliE1NRXnzp2DXC5H
O4uVNwAADLNJREFUQkKC1LGUjB07Fjt37lSaxcTEICgoCJmZmQgKCkJMTIxE
6ZSpyhocHIxz587hzJkzaNeuHebPny9RuqpU5QUqn0Du2bMHjo6OEqRSTVXW
/fv3IykpCWfOnMFvv/2GDz/8UCOPXe8KwtbWFl5eXgAAc3NzuLm5ITc3V+JU
1cvJycH27dsxfvx4qaOoVVxcjEOHDiEiIgIAYGpqCktLS4lTVU8mk6GkpAQy
mQwPHjyAnZ2d1JGU9O7dG82aNVOaJSUlITw8HAAQHh6OxMREKaJVoSpr3759
YWxcuaNAt27dkJOTI0U0lVTlBYD3338fn332GQwMDCRIpZqqrF9//TWioqLQ
oEEDAICNjY1GHrveFcTfZWdnIy0tDX5+flJHqdbUqVPx2WefwdBQ939VWVlZ
sLa2xltvvQVPT0+MHz8e9+/flzqWSvb29vjwww/h6OgIW1tbWFhYoG/fvlLH
UuvGjRuwtbUFUPlk5+bNmxInqplvv/0Wr7zyitQxnmjr1q2wt7dHly5dpI6i
1sWLF3H48GH4+fnB398fJ06c0Mjj6P5fHQ25d+8eBg8ejCVLlqBp06ZSx1Fp
27ZtsLGx0ZtT72QyGU6dOoVJkyYhLS0NjRs31pm3QB5XWFiIpKQkXL58Gdev
X8f9+/exbt06qWPVSfPmzYOxsTFGjRoldZRqPXjwAPPmzcOnn34qdZQakclk
KCwsREpKChYuXIhhw4ZBEyek1suCKC8vx+DBgzFq1CgMGjRI6jjVOnr0KLZu
3QonJyeMGDEC+/btw5tvvil1rGo5ODjAwcFB8YpsyJAhOHXqlMSpVNu7dy+c
nZ1hbW0NExMTDBo0CMeOHZM6llotWrRAXl4eACAvL09jby3Ulvj4eGzbtg3r
16/XqbdtHnfp0iVcvnwZXbp0gZOTE3JycuDl5YU///xT6mgqOTg4YNCgQTAw
MICvry8MDQ01clC93hWEEAIRERFwc3PDtGnTpI7zRPPnz0dOTg6ys7ORkJCA
Pn366PSz3JYtW6JVq1bIyMgAACQnJ6NDhw4Sp1LN0dERKSkpePDgAYQQSE5O
1tkD6n8XGhqK+Ph4AJV/fMPCwiROVL2dO3diwYIF2Lp1Kxo1aiR1nCdyd3fH
zZs3kZ2djezsbDg4OODUqVNo2bKl1NFUeu2117Bv3z4AlW83lZWVoXnz5rX/
QKKeOXz4sAAg3N3dRZcuXUSXLl3E9u3bpY6l1v79+8WAAQOkjqFWWlqa8Pb2
Fu7u7iIsLEwUFBRIHalas2bNEq6urqJjx47izTffFKWlpVJHUjJixAjRsmVL
YWxsLOzt7cWqVavErVu3RJ8+fUSbNm1Enz59xO3bt6WOKYRQnfXFF18UDg4O
iv9nb7/9ttQxFVTl/bvWrVuL/Px8idIpU5X14cOHYtSoUaJjx47C09NTJCcn
a+SxuZKaiIhUqndvMRERUc2wIIiISCUWBBERqcSCICIilVgQRESkEguCaszA
wAAffPCB4uNFixahtvabGjt2LDZv3lwrX+tJNm3aBDc3NwQGBirNDxw4oBdX
y31W0dHRNbrdd999h3fffVfl57Zu3ap2ZfysWbOwd+/ep85HuokFQTXWoEED
bNmyRWcug/yIXC6v8W3j4uLw1VdfYf/+/RpM9BeZTKaVx1GnpgVRHZlMhtDQ
UERFRT3xdp9++ilefvnl53os0h0sCKoxY2NjREZGYvHixVU+9/grgCZNmgCo
fGbu7++PYcOGoV27doiKisL69evh6+sLd3d3XLp0SXGfvXv34qWXXkK7du2w
bds2AJV//KdPn46uXbuic+fOWLlypeLrBgYG4o033oC7u3uVPBs2bIC7uzs6
deqEGTNmAKj843XkyBFMnDgR06dPr3Kfe/fuKfayGDVqlOLaNsnJyfD09IS7
uzvGjRuHhw8fAgCcnJwUZZmamoqAgAAAwJw5cxAZGYm+fftizJgx+O233+Dr
6wsPDw907twZmZmZSo8rl8sxduxYdOrUCe7u7oqfb0BAAKZOnYoePXqgU6dO
OH78OADg/v37GDduHLp27QpPT08kJSUBqHz2P2jQIPTr1w9t27ZV7BEQFRWF
kpISeHh4qLwe0urVq9GuXTv4+/vj6NGjSr/TadOmITAwEDNmzFC8urhz5w6c
nJxQUVEBoPI6Rq1atUJ5ebnSvwMnJyfMnj0bXl5ecHd3x4ULFwAA+fn5CA4O
hpeXF95++220bt1a55500P/TyPI7qpMaN24s7ty5I1q3bi2KiorEwoULxezZ
s4UQQoSHh4tNmzYp3VaIyhXgFhYW4vr166K0tFTY2dmJWbNmCSGEWLJkiZgy
ZYri/iEhIUIul4uLFy8Ke3t7UVJSIlauXCnmzp0rhBCitLRUeHt7i6ysLLF/
/37RqFEjkZWVVSVnbm6uaNWqlbh586YoLy8XgYGB4n//+58QQgh/f39x4sSJ
KvfZv3+/aNq0qbh27ZqQy+WiW7du4vDhw6KkpEQ4ODiIjIwMIYQQo0ePFosX
LxZCKK+2PXHihPD39xdCCDF79mzh5eUlHjx4IIQQ4t133xXr1q0TQgjx8OFD
xfyR1NRU8fLLLys+LiwsVGQdP368EEKIgwcPio4dOwohhJg5c6ZYu3at4rZt
27YV9+7dE6tXrxbOzs6iqKhIlJSUCEdHR3H16lWl38fjrl+/rvhZPXz4UPTo
0UO88847it/JgAEDhEwmE0IIsXr1asXnQkNDxb59+4QQQiQkJIiIiAjFfR79
O2jdurVYtmyZEEKIFStWKG7zzjvviOjoaCGEEDt27BAAdGbVMinjKwh6Kk2b
NsWYMWOwbNmyGt+na9eusLW1RYMGDfDiiy8qLqvt7u6O7Oxsxe2GDRsGQ0ND
tG3bFi4uLrhw4QJ2796NNWvWwMPDA35+frh9+7biGbivry+cnZ2rPN6JEycQ
EBAAa2trxVVEDx06pDanr68vHBwcYGhoCA8PD2RnZyMjIwPOzs5o164dgMo9
GGrytUJDQ2FmZgYA6N69O6Kjo7FgwQJcuXJFMX/ExcUFWVlZeO+997Bz506l
qwuPHDkSQOWeAMXFxSgqKsLu3bsRExMDDw8PBAQEoLS0FFevXgUABAUFwcLC
Ag0bNkSHDh1w5cqVJ+b89ddfFT8rU1NTDB8+XOnzQ4cOhZGRUZX7DR8+HBs3
bgQAJCQkVLnfI48uhunt7a34XR85cgQjRowAAPTr1w9WVlZPzEjSYUHQU5s6
dSri4uKU9nowNjZWvOUghEBZWZnic482NQEAQ0NDxceGhoZK79E/frVPAwMD
CCGwfPlynD59GqdPn8bly5cVBdO4cWOV+cQzXj3m7zmNjIwgk8me+LX+/j0/
vl3p37O98cYb2Lp1K8zMzBASEqK4yNojVlZWSE9PR0BAAFasWKG0OVR1P5Mf
f/xR8TO5evWq4kKDqr4HdZ50ldXqfsahoaHYsWMHCgoKcPLkSfTp00fl7R7l
+XuWZ/39kPaxIOipNWvWDMOGDUNcXJxi5uTkhJMnTwKo3PWsvLz8qb/upk2b
UFFRgUuXLiErKwuurq4ICQnB119/rfh6Fy9eVLsJkZ+fHw4ePIhbt25BLpdj
w4YN8Pf3f+o8ANC+fXtkZ2fjjz/+AACsXbtW8bX+/j3/+OOP1X6NrKwsuLi4
YPLkyQgNDcWZM2eUPn/r1i1UVFRg8ODBmDt3rtIl0h89Sz9y5AgsLCxgYWGB
kJAQLF++XPGHNi0tTe33YWJiovJ34ufnhwMHDuD27dsoLy/Hpk2b1H4toPIY
k6+vL6ZMmYKBAweqfJVRnV69euGHH34AAOzevVtn9tWmqoylDkD66YMPPsCX
X36p+HjChAkICwuDr68vgoKCqn3m+SSurq7w9/fHjRs38M0336Bhw4YYP348
srOz4eXlBSEErK2t1W6zaWtri/nz5yMwMBBCCPTv3/+ZL4vdsGFDrF69GkOH
DoVMJkPXrl0xceJEAMDs2bMRERGB6OjoJ+5KuHHjRqxbtw4mJiZo2bIlZs2a
pfT53NxcvPXWW4pXI3/fu9nKygo9evRAcXExvv32WwDAJ598gqlTp6Jz584Q
QsDJyUlxUL86kZGR6Ny5M7y8vLB+/XrF3NbWFnPmzEH37t0V2/HW9Kyw4cOH
Y+jQoThw4ECNbv/I7NmzMXLkSGzcuBH+/v6wtbWFubn5U30N0g5ezZVIRwUE
BGDRokXw8fGROkqtevjwIYyMjGBsbIxffvkFkyZNwunTp6WORSrwFQQRadXV
q1cxbNgwVFRUwNTUFP/973+ljkTV4CsIIiJSiQepiYhIJRYEERGpxIIgIiKV
WBBERKQSC4KIiFRiQRARkUr/B1NXSsoapccDAAAAAElFTkSuQmCC
" /></p>
<p style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><br /></p>
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" color:#000080;">In [</span><span style=" font-weight:600; color:#000080;">2</span><span style=" color:#000080;">]:</span> </p></body></html>