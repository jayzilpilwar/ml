import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from statistics import mean



data = pd.read_csv('aas10.csv')
print(data)

x=data[data.columns[0]].values
y=data[data.columns[1]].values

#xs=np.array(x,dtype=np.float64)
#ys=np.array(y,dtype=np.float64)

print(x)
print(y)

#sum of x 
xres=sum(x)
print("sum of x= "+np.str(xres))

#sum of y
yres=sum(y)
print("sum of y= "+np.str_(yres))

#sum of x*y
xy = np.multiply(x,y)
xyres=sum(xy)
print("sum of xy= "+np.str_(xyres))

#sum of x*x
xx = np.multiply(x,x)
xxres=sum(xx)
print("Square of x= "+np.str_(xxres))

n_x=len(x)
n_y=len(y)



a=((n_x*xyres)-(xres*yres))  / ((n_x*xxres)-(xres*xres))
print(a)

b=(1/n_x)*(yres-(a*xres))
print(b)

print("y="+np.str_(a)+"x+"+np.str_(b));

xz=input("Year-")
year=np.int(xz)-2005

xz1=np.float64(year)

result=float(a*xz1+b)

print("The estimated sales in "+ np.str_(xz) +" are "+np.str_(result)+" million dollars")

