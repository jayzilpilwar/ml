
package rsa;
import java.math.*;

import java.util.*;

public class RSA 
{

   
   static int gcd(int e,int z)
   {
     if(e==0)
         return z;
     else
         return gcd((z%e),e);
   }        
   public static void main(String args[])
   {        
    Scanner sc=new Scanner(System.in);
   
    int a=sc.nextInt();
    int b=sc.nextInt();
    
    int n=a*b;
    
    System.out.println("N- "+n);
    
    int z=(a-1)*(b-1);
    
    System.out.println("Z- "+z);
    
    int msg=sc.nextInt();
    
    int d=0,e,c;
    
    BigInteger bckmsg;
    
    for(e=2;e<z;e++)
    {
      if(gcd(e,z)==1)
          break;
    }    
    
    for(int i=0;i<=9;i++)
    {
      int x=1+(i*z);
      if(x%e==0)
      {
         d=x/e;
         break;
      }    
    
    }    
    
    
    System.out.println("Encrypted Key- "+e);
    System.out.println("Decrypted Key- "+d);
    
    
    c=(int)Math.pow(msg,e)%n;
    System.out.println("Cipher text- "+c);
    
    
    BigInteger N=BigInteger.valueOf(n);
    BigInteger C=BigInteger.valueOf(c);
    
    bckmsg=(C.pow(d)).mod(N);
    System.out.println("plain text- "+bckmsg);
    
    
    
       

    }
    
}
