import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data=pd.read_csv('ass3.csv')
x=data[data.columns[0]].values
y=data[data.columns[1]].values

#sum of x
xres=sum(x)
print('Sum of x-'+np.str_(xres))

#sum of y
yres=sum(y)
print('Sum of y-'+np.str_(yres))

#sum of x*y
xy = np.multiply(x,y)
xyres=sum(xy)
print("sum of xy= "+np.str_(xyres))


#sum of x*x
xx = np.multiply(x,x)
xxres=sum(xx)
print("sum of xy= "+np.str_(xxres))

n=len(x)

a=((n*xyres)-(xres*yres)) / ((n*xxres)-(xres*xres))

b=(1/n)*(yres-(a*xres))

val=input('Enter x-')
val1=np.float64(val)
res=(a*val1)+b
print(res)
