import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from statistics import mean
from matplotlib import style
style.use('ggplot')

data=pd.read_csv('Book_1.csv')
a=data[data.columns[0]].values
c=data[data.columns[1]].values


xs=np.array(a,dtype=np.float64)
ys=np.array(c,dtype=np.float64)

def best_fit_slope_and_intercept(xs,ys):
    m=( ((mean(xs)*mean(ys))-mean(xs*ys)) /
        ((mean(xs)*mean(xs))-mean(xs*xs)) )
    b=mean(ys)-m*mean(xs)
    return m,b

def square_error(ys_ori,ys_line):
    return sum((ys_line - ys_ori) * (ys_line - ys_ori))

def coefficient_of_determination(ys_ori,ys_line):
    ys_mean=[mean(ys_ori) for y in ys_ori]
    squared_error_reg=square_error(ys_ori,ys_line)
    squared_error_Y_mean=square_error(ys_ori,ys_mean)
    return 1-(squared_error_reg/squared_error_Y_mean)


m,b = best_fit_slope_and_intercept(xs,ys)

print("y ="+np.str_(m)+"x+"+np.str_(b))



regression_line=[]
for x in xs:
    regression_line.append((m*x)+b)


#option
X_in=2
predict_y = (m*X_in)+b
print(predict_y)


r_squared = coefficient_of_determination(ys,regression_line)
print('R Square-'+np.str_(r_squared))


plt.scatter(xs,ys,c='g')
plt.plot(xs,regression_line)
plt.plot(xs,ys)
plt.show()    
    
