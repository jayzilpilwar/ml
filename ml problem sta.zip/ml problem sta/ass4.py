import numpy as np
import pandas as pd
import pydotplus

from sklearn.externals.six import StringIO
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import export_graphviz
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split


data=pd.read_csv('ass4.csv')
x=data.iloc[:,0:4]
y=data.iloc[:,4]


le=LabelEncoder()
X=x.apply(le.fit_transform)
print(X)

X_train, X_test, y_train, y_test = train_test_split( X, y, test_size = 0.3, random_state =0)
Classifier=DecisionTreeClassifier(criterion='entropy')
Classifier.fit(X_train, y_train)


result=Classifier.predict(X_test)
print("Accuracy is -"+np.str_(accuracy_score(y_test,result)*100)+"%")

pred=np.array([2,2,0,1])
res1=Classifier.predict([pred])
print("Row 8-"+res1)




dot_data=StringIO()
export_graphviz(Classifier,out_file=dot_data,filled=True,rounded=True,special_characters=True)
graph=pydotplus.graph_from_dot_data(dot_data.getvalue())
graph.write_png('tree.png')

