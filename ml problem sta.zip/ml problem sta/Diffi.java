
package diffie.helman;
import java.util.*;
public class DiffieHelman 
{

   
    public static void main(String[] args) 
    {
       
	Scanner sc=new Scanner(System.in);
	int p=sc.nextInt();
	int q=sc.nextInt();
	int a=sc.nextInt();
	int b=sc.nextInt();
	
	int R= (int)Math.pow(q,a)%p;
	int S= (int)Math.pow(q,b)%p;
	
	int S_A=(int)Math.pow(S,a)%p;
	int S_B=(int)Math.pow(R,b)%p;
	
	if(S_A==S_B)
	{
	   System.out.println("Agree on key- "+S_A);
	}
	else
	{
	   System.out.println("Not Agree");
	}
	
	
    }
    
}
