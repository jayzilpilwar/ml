
import numpy as np
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier



data=pd.read_csv('ass8.csv')
print(data)
x=data.iloc[:,:-1].values
y=data.iloc[:,2].values


clas=KNeighborsClassifier(n_neighbors=3)
clas.fit(x,y)

pres=np.array([6,6])
sd=clas.predict([pres])
print(sd)
